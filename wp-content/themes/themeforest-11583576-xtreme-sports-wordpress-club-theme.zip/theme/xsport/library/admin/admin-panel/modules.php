<?php

/**** ADMIN PANEL MODULE ****/

$panelPath =  get_template_directory() . '/library/admin/admin-panel/';

require_once ($panelPath . 'general-settings.php');
?>
