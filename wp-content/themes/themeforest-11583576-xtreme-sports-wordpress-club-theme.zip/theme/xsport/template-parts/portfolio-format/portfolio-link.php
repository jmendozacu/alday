
<div class="detail-item">
    <a  href="<?php echo esc_url(get_permalink(get_the_ID())) ?>"   data-toggle="modal" class="btn-icon  btn-info"  data-target="#myModal<?php echo esc_attr(get_the_ID()); ?>" >
        <span class="icon-magnifier" aria-hidden="true"></span>
    </a>
    
    
</div>


