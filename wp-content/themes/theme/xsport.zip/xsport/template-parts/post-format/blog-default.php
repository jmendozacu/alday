<?php
	// get meta options/values
?>

<div class="entry-media">
	<div class="entry-content">
    		
        <h3 class="entry-title"> <a href="<?php esc_url(the_permalink())?>"><?php the_title() ?></a> </h3>       
                
		<div class="media-info">
			<p><?php echo get_the_excerpt() ?></p>
		</div>
	</div>
</div>